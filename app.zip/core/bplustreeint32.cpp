#include "BPlusTreeInt32.h"
#include <cstring>
#include <stdexcept>
#include <algorithm>

namespace ma {

static constexpr int LEAF_ENTRY_SIZE = sizeof(LeafEntry);
static constexpr int INTERNAL_ENTRY_SIZE = sizeof(InternalEntry);
static constexpr int CHILD_PTR_SIZE = sizeof(uint32_t);

int BPlusTreeInt32::maxLeafEntries() {
    return (PAGE_SIZE - (int)sizeof(NodeHdr)) / LEAF_ENTRY_SIZE;
}
int BPlusTreeInt32::maxInternalKeys() {
    int M = (PAGE_SIZE - (int)sizeof(NodeHdr) - (int)sizeof(uint32_t)) /
            (INTERNAL_ENTRY_SIZE + (int)sizeof(uint32_t));
    return std::max(3, M-1); // holgura
}
int BPlusTreeInt32::minLeafEntries() {
    return std::max(1, maxLeafEntries() / 2);
}
int BPlusTreeInt32::minInternalKeys() {
    return std::max(1, maxInternalKeys() / 2);
}

BPlusTreeInt32::BPlusTreeInt32(IndexStorage* storage): st_(storage) {}
bool BPlusTreeInt32::isEmpty() const { return st_->rootPageId() == 0; }

uint32_t BPlusTreeInt32::ensureRootLeaf() {
    if (!isEmpty()) return root();
    Page leaf;
    leaf.hdr.pageId = st_->allocatePage();
    NodeHdr nh{};
    nh.pageId   = leaf.hdr.pageId;
    nh.isLeaf   = 1;
    nh.keyCount = 0;
    nh.parent   = 0;
    nh.nextLeaf = 0;
    std::memcpy(leaf.bytes.data(), &nh, sizeof(NodeHdr));
    write(leaf);
    setRoot(leaf.hdr.pageId);
    return leaf.hdr.pageId;
}

void BPlusTreeInt32::createEmpty() { ensureRootLeaf(); }

uint32_t BPlusTreeInt32::findLeafForKey(int32_t k) {
    uint32_t pid = ensureRootLeaf();
    Page p = read(pid);
    while (!NHc(p).isLeaf) {
        int M = maxInternalKeys();
        const auto* keys = IEc(p);
        const auto* ch = CHILDc(p, M);
        int kc = NHc(p).keyCount;
        (void)keys; (void)kc;
        int i = internalChildIndex(p, k);
        pid = ch[i];
        p = read(pid);
    }
    return pid;
}

int BPlusTreeInt32::leafLowerBound(const Page& leaf, int32_t k) {
    int lo = 0, hi = NHc(leaf).keyCount;
    const auto* a = LEc(leaf);
    while (lo < hi) {
        int mid = (lo + hi) / 2;
        if (a[mid].key < k) lo = mid + 1; else hi = mid;
    }
    return lo;
}
int BPlusTreeInt32::leafUpperBound(const Page& leaf, int32_t k) {
    int lo = 0, hi = NHc(leaf).keyCount;
    const auto* a = LEc(leaf);
    while (lo < hi) {
        int mid = (lo + hi) / 2;
        if (a[mid].key <= k) lo = mid + 1; else hi = mid;
    }
    return lo;
}
int BPlusTreeInt32::internalChildIndex(const Page& internal, int32_t k) {
    int kc = NHc(internal).keyCount;
    const auto* a = IEc(internal);
    int i = 0;
    while (i < kc && k >= a[i].key) ++i;
    return i;
}

void BPlusTreeInt32::insert(int32_t key, RID rid) {
    uint32_t leafPid = findLeafForKey(key);
    Page leaf = read(leafPid);
    int maxE = maxLeafEntries();
    if (NHc(leaf).keyCount < maxE) {
        insertIntoLeaf(leaf, key, rid);
        write(leaf);
    } else {
        splitLeafAndInsert(leaf, key, rid);
    }
}

void BPlusTreeInt32::insertIntoLeaf(Page& leaf, int32_t k, RID rid) {
    int pos = leafUpperBound(leaf, k);
    int kc = NHc(leaf).keyCount;
    auto* a = LE(leaf);
    for (int i = kc; i > pos; --i) a[i] = a[i-1];
    a[pos].key = k; a[pos].ridPage = rid.pageId; a[pos].ridSlot = rid.slotId; a[pos].pad=0;
    NH(leaf).keyCount = kc + 1;
}

void BPlusTreeInt32::splitLeafAndInsert(Page& leaf, int32_t k, RID rid) {
    Page right;
    right.hdr.pageId = st_->allocatePage();
    NodeHdr rnh{}; rnh.pageId=right.hdr.pageId; rnh.isLeaf=1; rnh.keyCount=0; rnh.parent=NHc(leaf).parent; rnh.nextLeaf=NHc(leaf).nextLeaf;
    std::memcpy(right.bytes.data(), &rnh, sizeof(NodeHdr));

    int kc = NHc(leaf).keyCount;
    int move = kc/2;
    auto* la = LE(leaf);
    auto* ra = LE(right);
    for (int i=0;i<move;i++) ra[i] = la[kc - move + i];
    NH(right).keyCount = move;
    NH(leaf).keyCount = kc - move;
    NH(leaf).nextLeaf = right.hdr.pageId;

    if (k >= LEc(right)[0].key) insertIntoLeaf(right, k, rid);
    else insertIntoLeaf(leaf, k, rid);

    write(leaf); write(right);

    int32_t sepKey = LEc(right)[0].key;
    insertIntoParent(leaf.hdr.pageId, sepKey, right.hdr.pageId);
}

void BPlusTreeInt32::insertIntoParent(uint32_t leftPid, int32_t sepKey, uint32_t rightPid) {
    if (leftPid == root()) {
        Page rootp;
        rootp.hdr.pageId = st_->allocatePage();
        NodeHdr nh{}; nh.pageId=rootp.hdr.pageId; nh.isLeaf=0; nh.keyCount=1; nh.parent=0; nh.nextLeaf=0;
        std::memcpy(rootp.bytes.data(), &nh, sizeof(NodeHdr));

        int M = maxInternalKeys();
        auto* keys = IE(rootp);
        auto* ch = CHILD(rootp, M);
        keys[0].key = sepKey;
        ch[0] = leftPid;
        ch[1] = rightPid;

        Page L = read(leftPid); NH(L).parent = rootp.hdr.pageId; write(L);
        Page R = read(rightPid); NH(R).parent = rootp.hdr.pageId; write(R);

        write(rootp);
        setRoot(rootp.hdr.pageId);
        return;
    }

    Page left = read(leftPid);
    uint32_t parentPid = NHc(left).parent;
    Page parent = read(parentPid);

    int M = maxInternalKeys();
    auto* keys = IE(parent);
    auto* ch = CHILD(parent, M);
    int kc = NHc(parent).keyCount;

    int iChild = 0; while (iChild <= kc && ch[iChild] != leftPid) ++iChild;
    if (iChild > kc) throw std::runtime_error("B+ parent child not found");

    for (int i = kc; i > iChild; --i) keys[i] = keys[i-1];
    for (int i = kc+1; i > iChild+1; --i) ch[i] = ch[i-1];
    keys[iChild].key = sepKey;
    ch[iChild+1] = rightPid;
    NH(parent).keyCount = kc + 1;

    if (NHc(parent).keyCount <= maxInternalKeys()) {
        write(parent);
        Page R = read(rightPid); NH(R).parent = parent.hdr.pageId; write(R);
    } else {
        splitInternalAndInsert(parent, 0 /*dummy*/, 0 /*unused*/);
        Page R = read(rightPid); write(R);
    }
}

void BPlusTreeInt32::splitInternalAndInsert(Page& node, int32_t /*sepKeyUnused*/, uint32_t /*rightPidUnused*/) {
    int kc = NHc(node).keyCount;
    int mid = kc/2;
    int M = maxInternalKeys();

    Page right;
    right.hdr.pageId = st_->allocatePage();
    NodeHdr nh{}; nh.pageId=right.hdr.pageId; nh.isLeaf=0; nh.keyCount=0; nh.parent=NHc(node).parent; nh.nextLeaf=0;
    std::memcpy(right.bytes.data(), &nh, sizeof(NodeHdr));

    auto* keysL = IE(node);
    auto* chL   = CHILD(node, M);
    auto* keysR = IE(right);
    auto* chR   = CHILD(right, M);

    int32_t promote = keysL[mid].key;

    int rkeys = kc - (mid + 1);
    for (int i=0;i<rkeys;i++) keysR[i] = keysL[mid+1 + i];
    for (int i=0;i<rkeys+1;i++) chR[i] = chL[mid+1 + i];

    NH(node).keyCount = mid;

    for (int i=0;i<rkeys+1;i++) {
        Page c = read(chR[i]); NH(c).parent = right.hdr.pageId; write(c);
    }

    NH(right).keyCount = rkeys;
    write(node); write(right);

    insertIntoParent(node.hdr.pageId, promote, right.hdr.pageId);
}

std::vector<RID> BPlusTreeInt32::find(int32_t key) {
    uint32_t leafPid = findLeafForKey(key);
    Page leaf = read(leafPid);
    int lo = leafLowerBound(leaf, key);
    int hi = leafUpperBound(leaf, key);
    std::vector<RID> out;
    const auto* a = LEc(leaf);
    for (int i=lo;i<hi;i++) out.push_back(RID{a[i].ridPage, a[i].ridSlot});
    return out;
}

std::vector<RID> BPlusTreeInt32::range(int32_t keyMin, int32_t keyMax) {
    if (keyMax < keyMin) return {};
    std::vector<RID> out;
    uint32_t pid = findLeafForKey(keyMin);
    Page leaf = read(pid);
    while (true) {
        const auto* a = LEc(leaf);
        int kc = NHc(leaf).keyCount;
        for (int i=0;i<kc;i++) {
            if (a[i].key < keyMin) continue;
            if (a[i].key > keyMax) return out;
            out.push_back(RID{a[i].ridPage, a[i].ridSlot});
        }
        if (NHc(leaf).nextLeaf == 0) break;
        leaf = read(NHc(leaf).nextLeaf);
    }
    return out;
}

bool BPlusTreeInt32::removeFromLeaf(Page& leaf, int32_t k, RID rid) {
    auto* a = LE(leaf);
    int kc = NHc(leaf).keyCount;
    for (int i=0;i<kc;i++) {
        if (a[i].key==k && a[i].ridPage==rid.pageId && a[i].ridSlot==rid.slotId) {
            for (int j=i+1;j<kc;j++) a[j-1]=a[j];
            NH(leaf).keyCount = kc-1;
            return true;
        }
    }
    return false;
}

void BPlusTreeInt32::remove(int32_t key, RID rid) {
    uint32_t leafPid = findLeafForKey(key);
    Page leaf = read(leafPid);
    if (removeFromLeaf(leaf, key, rid)) {
        write(leaf);
        rebalanceAfterDelete(leafPid);
    }
}

int32_t BPlusTreeInt32::firstKeyLeaf(const Page& leaf) {
    if (NHc(leaf).keyCount == 0) return INT32_MIN;
    return LEc(leaf)[0].key;
}
int32_t BPlusTreeInt32::firstKeyInternal(const Page& internal) {
    if (NHc(internal).keyCount == 0) return INT32_MIN;
    return IEc(internal)[0].key;
}

void BPlusTreeInt32::rebalanceAfterDelete(uint32_t pid) {
    Page node = read(pid);

    if (pid == root()) {
        if (!NHc(node).isLeaf && NHc(node).keyCount == 0) {
            int M = maxInternalKeys();
            auto* ch = CHILD(node, M);
            uint32_t newRootPid = ch[0];
            Page child = read(newRootPid);
            NH(child).parent = 0;
            write(child);
            setRoot(newRootPid);
        }
        return;
    }

    int minReq = NHc(node).isLeaf ? minLeafEntries() : minInternalKeys();
    if (NHc(node).keyCount >= minReq) return;

    uint32_t parentPid = NHc(node).parent;
    Page parent = read(parentPid);
    int M = maxInternalKeys();
    auto* ch = CHILD(parent, M);
    int kcP = NHc(parent).keyCount;
    int idx = 0; while (idx <= kcP && ch[idx] != pid) ++idx;
    if (idx > kcP) throw std::runtime_error("rebalance: child not found in parent");

    if (NHc(node).isLeaf) {
        if (idx > 0) {
            Page left = read(ch[idx-1]);
            if (NHc(left).keyCount > minLeafEntries()) {
                if (borrowFromLeftLeaf(parent, idx-1, left, node)) { write(parent); write(left); write(node); return; }
            }
        }
        if (idx < kcP) {
            Page right = read(ch[idx+1]);
            if (NHc(right).keyCount > minLeafEntries()) {
                if (borrowFromRightLeaf(parent, idx, node, right)) { write(parent); write(right); write(node); return; }
            }
        }
        if (idx > 0) {
            Page left = read(ch[idx-1]);
            mergeLeaves(parent, idx-1, left, node);
            write(parent); write(left);
            rebalanceAfterDelete(parentPid);
            return;
        } else {
            Page right = read(ch[idx+1]);
            mergeLeaves(parent, idx, node, right);
            write(parent); write(node);
            rebalanceAfterDelete(parentPid);
            return;
        }
    } else {
        if (idx > 0) {
            Page left = read(ch[idx-1]);
            if (NHc(left).keyCount > minInternalKeys()) {
                if (borrowFromLeftInternal(parent, idx-1, left, node)) { write(parent); write(left); write(node); return; }
            }
        }
        if (idx < kcP) {
            Page right = read(ch[idx+1]);
            if (NHc(right).keyCount > minInternalKeys()) {
                if (borrowFromRightInternal(parent, idx, node, right)) { write(parent); write(right); write(node); return; }
            }
        }
        if (idx > 0) {
            Page left = read(ch[idx-1]);
            mergeInternals(parent, idx-1, left, node);
            write(parent); write(left);
            rebalanceAfterDelete(parentPid);
            return;
        } else {
            Page right = read(ch[idx+1]);
            mergeInternals(parent, idx, node, right);
            write(parent); write(node);
            rebalanceAfterDelete(parentPid);
            return;
        }
    }
}

bool BPlusTreeInt32::borrowFromLeftLeaf(Page& parent, int sepIdx, Page& left, Page& node) {
    int kcL = NHc(left).keyCount;
    int kcN = NHc(node).keyCount;
    if (kcL <= minLeafEntries()) return false;

    auto* aL = LE(left);
    auto* aN = LE(node);
    for (int i=kcN; i>0; --i) aN[i] = aN[i-1];
    aN[0] = aL[kcL-1];
    NH(node).keyCount = kcN + 1;
    NH(left).keyCount = kcL - 1;

    IE(parent)[sepIdx].key = firstKeyLeaf(node);
    return true;
}

bool BPlusTreeInt32::borrowFromRightLeaf(Page& parent, int sepIdx, Page& node, Page& right) {
    int kcR = NHc(right).keyCount;
    int kcN = NHc(node).keyCount;
    if (kcR <= minLeafEntries()) return false;

    auto* aR = LE(right);
    auto* aN = LE(node);
    aN[kcN] = aR[0];
    for (int i=1;i<kcR;i++) aR[i-1] = aR[i];
    NH(node).keyCount = kcN + 1;
    NH(right).keyCount = kcR - 1;

    IE(parent)[sepIdx].key = firstKeyLeaf(right);
    return true;
}

void BPlusTreeInt32::mergeLeaves(Page& parent, int sepIdxLeft, Page& left, Page& right) {
    int kcL = NHc(left).keyCount;
    int kcR = NHc(right).keyCount;
    auto* aL = LE(left);
    const auto* aR = LEc(right);
    for (int i=0;i<kcR;i++) aL[kcL+i] = aR[i];
    NH(left).keyCount = kcL + kcR;

    NH(left).nextLeaf = NHc(right).nextLeaf;

    int M = maxInternalKeys();
    auto* keysP = IE(parent);
    auto* chP = CHILD(parent, M);
    int kcP = NHc(parent).keyCount;

    for (int i=sepIdxLeft; i<kcP-1; ++i) keysP[i] = keysP[i+1];
    for (int i=sepIdxLeft+1; i<kcP; ++i) chP[i] = chP[i+1];
    NH(parent).keyCount = kcP - 1;
}

bool BPlusTreeInt32::borrowFromLeftInternal(Page& parent, int sepIdx, Page& left, Page& node) {
    int kcL = NHc(left).keyCount;
    int kcN = NHc(node).keyCount;
    if (kcL <= minInternalKeys()) return false;

    int M = maxInternalKeys();
    auto* keysL = IE(left);
    auto* chL   = CHILD(left, M);
    auto* keysN = IE(node);
    auto* chN   = CHILD(node, M);

    for (int i=kcN; i>0; --i) keysN[i] = keysN[i-1];
    for (int i=kcN+1; i>0; --i) chN[i] = chN[i-1];

    keysN[0].key = IEc(parent)[sepIdx].key;
    chN[0] = chL[kcL];

    IE(parent)[sepIdx].key = keysL[kcL-1].key;

    NH(left).keyCount = kcL - 1;
    NH(node).keyCount = kcN + 1;

    Page movedChild = read(chN[0]);
    NH(movedChild).parent = node.hdr.pageId;
    write(movedChild);
    return true;
}

bool BPlusTreeInt32::borrowFromRightInternal(Page& parent, int sepIdx, Page& node, Page& right) {
    int kcR = NHc(right).keyCount;
    int kcN = NHc(node).keyCount;
    if (kcR <= minInternalKeys()) return false;

    int M = maxInternalKeys();
    auto* keysR = IE(right);
    auto* chR   = CHILD(right, M);
    auto* keysN = IE(node);
    auto* chN   = CHILD(node, M);

    keysN[kcN].key = IEc(parent)[sepIdx].key;
    chN[kcN+1] = chR[0];

    IE(parent)[sepIdx].key = keysR[0].key;

    for (int i=1;i<kcR;i++) keysR[i-1] = keysR[i];
    for (int i=1;i<kcR+1;i++) chR[i-1] = chR[i];

    NH(right).keyCount = kcR - 1;
    NH(node).keyCount  = kcN + 1;

    Page movedChild = read(chN[kcN+1]);
    NH(movedChild).parent = node.hdr.pageId;
    write(movedChild);
    return true;
}

void BPlusTreeInt32::mergeInternals(Page& parent, int sepIdxLeft, Page& left, Page& right) {
    int kcL = NHc(left).keyCount;
    int kcR = NHc(right).keyCount;
    int M = maxInternalKeys();

    auto* keysL = IE(left);
    auto* chL   = CHILD(left, M);
    const auto* keysR = IEc(right);
    const auto* chR   = CHILDc(right, M);

    keysL[kcL].key = IEc(parent)[sepIdxLeft].key;
    chL[kcL+1] = chR[0];

    for (int i=0;i<kcR;i++) keysL[kcL+1+i] = keysR[i];
    for (int i=1;i<kcR+1;i++) chL[kcL+1+i] = chR[i];

    for (int i=0;i<kcR+1;i++) {
        Page c = read(chR[i]); NH(c).parent = left.hdr.pageId; write(c);
    }

    NH(left).keyCount = kcL + 1 + kcR;

    auto* keysP = IE(parent);
    auto* chP   = CHILD(parent, M);
    int kcP = NHc(parent).keyCount;
    for (int i=sepIdxLeft; i<kcP-1; ++i) keysP[i] = keysP[i+1];
    for (int i=sepIdxLeft+1; i<kcP;   ++i) chP[i]   = chP[i+1];
    NH(parent).keyCount = kcP - 1;
}

}
