#pragma once
#include <QApplication>

namespace gui {
void applyAppTheme(QApplication& app);
}
